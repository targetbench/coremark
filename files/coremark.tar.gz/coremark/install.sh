build_coremark() {
    set -e
    ARCH=`uname -i`
    if [ $ARCH = "x86_64" -o $ARCH = "x86_32" ]; then
        # -O2 -msse4
        make PORT_DIR=linux64 XCFLAGS=" -msse4 " compile
    elif [ $ARCH = "aarch32" ]; then
        # O2 -mfloat-abi=hard -mfpu=vfpv4 -mcpu=cortex-a15
        make PORT_DIR=linux XCFLAGS=" -mfloat-abi=hard -mfpu=vfpv4 -mcpu=cortex-a15 " compile
    elif [ $ARCH = "aarch64"  ]; then
        make PORT_DIR=linux64 compile
    else
        make PORT_DIR=linux64 compile
    fi

}

build_coremark

